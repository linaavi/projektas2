$('[data-fancybox="gallery1"]').fancybox({
	loop: true,
    animationEffect: "zoom",
    animationDuration: 1000,
    transitionEffect: "zoom-in-out",
    transitionDuration: 1000,
}); 
