<?php
   require __DIR__ . '/src/app.php';
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Phototime</title>
    <link href="fancybox/jquery.fancybox.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Varela+Round&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="CSS/style.css">
    <script src="https://kit.fontawesome.com/a400fc7be8.js" crossorigin="anonymous"></script>
</head>
<body>
    <?php
        include('views/header.php');
        include('views/content.php');
        include('views/footer.php');
    ?>
    
    <script src="js/jquery.js"></script>
    <script src="fancybox/jquery.fancybox.min.js"></script>
    <script src="js/custom.js"></script>
</body>
</html>
