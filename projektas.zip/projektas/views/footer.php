<footer>
    <div class="container back">
        <div class="left">
            <ul class="foot">
                <li><a href="#"><strong>CREDITS |</strong></a></li>
                <li><a href="#"><strong>PRIVACY |</strong></a></li>
                <li><a href="#"><strong>OUR TEAM</strong></a></li> 
            </ul>
            <p class="Copyright">&copy; <?php echo date('Y'); ?> all rights    reserved</p>
        </div>
        <div class="icon">
            <img src="images/logo.png" alt="Phototime_Logo">
        </div> 
    </div>
</footer>