    <article class="container box">
        <h2>RAPPRESENT YOUR LIFE WITH A <br> SIMPLE PHOTO</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, <br>sed do eiusmod tempor incididunt ut labore et dolore <br>magna aliqua. Ut <strong>enim ad minim</strong> veniam, quis <br> nostrud exercitation ullamco laboris nisi <br> ut aliquip ex ea commodo consequat.</p>
        <button>GET STARTED</button>
    </article>
    <article2 class="container box disign">
        <div style="float: right;">
            <h2>DESIGN</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, <br>sed do eiusmod tempor incididunt ut labore et dolore <br>magna aliqua. Ut <strong>enim ad minim</strong> veniam, quis <br> nostrud exercitation ullamco laboris nisi <br> ut aliquip ex ea commodo consequat.</p>
        <button>LEARN MORE</button> 
        </div>
            
    </article2>
    <article3 class="container community">
        <div class="first-column"> 
            <img  src="images/logo2.jpg" alt="Phototime_Logo">
            <h2>OUR COMMUNITY</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit,</p>
        </div>
        <div class="gallery">
            <div class="pirmas">
                <a data-fancybox="gallery1" href="images/1.jpg" >
                    <img src="images/1 small.jpg" alt="Phototime_team_members">
                </a>
            </div>
            <div class="antras">
                <a data-fancybox="gallery1" href="images/3.jpg">
                    <img src="images/3 small.jpg" alt="Phototime_team_members">     
                </a>
            </div>
            <div class="trecias">
                <a data-fancybox="gallery1" href="images/4.jpg">
                    <img src="images/4 small.jpg" alt="Phototime_team_members">
                </a>
            </div>
            <div class="ketvirtas">
                <a data-fancybox="gallery1" href="images/5.jpg">
                    <img src="images/5 small.jpg" alt="Phototime_team_members">
                </a>
            </div>
            <div class="penktas">
                <a data-fancybox="gallery1" href="images/6.jpg">
                    <img src="images/6 small.jpg" alt="Phototime_team_members">
                </a>
            </div>
            <div class="sestas">
                <a data-fancybox="gallery1" href="images/8.jpg">
                    <img src="images/8 small.jpg" alt="Phototime_team_members">
                </a>
            </div>
        </div>
    </article3>
    <contact class="container email">
        <form id="contact" action="index.php" method="post">
            <h2> CONTACT US</h2>
            <div class="input-box">
                <input type="text" name="vardas" placeholder="YOUR NAME" required autofocus> 
                <input type="email" name="email" placeholder="YOUR EMAIL" required>
            </div>
            <div class="text">
                <textarea name="message" placeholder="YOUR MESSAGE..."  required></textarea>
                <button class="btn" name="submit" type="submit" id="contact-submit"><i class="fas fa-check"></i></button> 
            </div>
        </form>                                 
    </contact>
    <download class="container down">
        <div class="load">
            <h2><strong>DOWNLOAD IT</strong></h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
        </div>
        <div class="shops">
            <button>APPLE STORE &nbsp; &nbsp; <i class="fab fa-apple"></i></button>
            <button>PLAY STORE &nbsp; &nbsp; <i class="fab fa-android"></i></button>
        </div>
    </download>