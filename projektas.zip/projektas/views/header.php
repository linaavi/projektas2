<header class="site-header">
        <div class="container">
            <ul class="nav">
                    <li><a href="#">HOME</a></li>
                    <li><a href="#">PHOTOAPP</a></li>
                    <li><img src="images/phototime_camera.png" alt="Phototime_logo"></li>
                    <li><a href="#">DESIGN</a></li>
                    <li><a href="#">DOWNLOAD</a></li>
            </ul>
            <div class="main">
                <h1>YOUR LIFE, A PHOTO</h1>
                <h2>print your life in a simple photo</h2>
                <button>GET STARTED</button>
            </div>
            <ul class="social">
                    <li><a href="https://twitter.com"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="https://www.facebook.com"><i class="fab fa-facebook"></i></a></li>
                    <li><a href="https://instagram.com"><i class="fab fa-instagram"></i></a></li>
            </ul>
        </div>
    </header>